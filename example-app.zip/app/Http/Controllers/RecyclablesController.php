<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RecyclablesController extends Controller
{
    //
}

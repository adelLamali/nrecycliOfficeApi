<?php echo e($slot); ?>

<?php /**PATH D:\nrecycli_office\officeApi\example-app\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>
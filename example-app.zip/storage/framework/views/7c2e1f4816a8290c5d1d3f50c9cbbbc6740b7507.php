<?php echo e($slot); ?>

<?php /**PATH D:\nrecycli_office\officeApi\example-app\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>
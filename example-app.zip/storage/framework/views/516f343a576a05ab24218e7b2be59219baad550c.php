<?php $__env->startComponent('mail::message'); ?>

<div>
  <p style="text-align:center;">
    <?php echo e(__('office.third_msg')); ?><?php echo e(__('office.fourth_msg')); ?> <strong style="color:#69bf37">« NRECYCLI OFFICE »</strong> <?php echo e(__('office.fifth_msg')); ?><br>
    <?php echo e(__('office.sixth_msg')); ?>

  </p>
</div>

<p style="text-align:center;">
  <strong><?php echo e(__('office.ordertitle')); ?></strong>
</p>   
 
<?php $__env->startComponent('mail::table'); ?>
| <?php echo e(__('office.item')); ?>          | <?php echo e(__('office.uniteprice')); ?>    | <?php echo e(__('office.count')); ?>     | <?php echo e(__('office.total')); ?>    |
| ------------- |:------------- |:------------- | :-------- | :--------|
<?php if($quotation['workshop_price']): ?>
|  <?php echo e(__('office.workshop')); ?>      |<?php echo e($quotation['workshop_price']); ?> <?php echo e(__('office.da')); ?>| x 1     | <?php echo e($quotation['workshop_price']); ?> <?php echo e(__('office.da')); ?> |
<?php endif; ?>
<?php if($quotation['order']['twoFlowBins']): ?>
|  <?php echo e(__('office.twostreams')); ?>    |23.800 <?php echo e(__('office.da')); ?>| x <?php echo e($quotation['order']['twoFlowBins']); ?>   | <?php echo e($quotation['order']['threeFlowBins'] * 23800); ?> <?php echo e(__('office.da')); ?> |
<?php endif; ?>
<?php if($quotation['order']['threeFlowBins']): ?>
|  <?php echo e(__('office.threestreams')); ?>   |29.700 <?php echo e(__('office.da')); ?>| x <?php echo e($quotation['order']['threeFlowBins']); ?> | <?php echo e($quotation['order']['twoFlowBins'] * 29700); ?> <?php echo e(__('office.da')); ?> |
<?php endif; ?>
<?php if($quotation['order']['indoorLooperPet']): ?>
|  <?php echo e(__('office.indoorlooperpet')); ?>   |1.850 <?php echo e(__('office.da')); ?>| x <?php echo e($quotation['order']['indoorLooperPet']); ?> | <?php echo e($quotation['order']['indoorLooperPet'] * 1850); ?> <?php echo e(__('office.da')); ?> |
<?php endif; ?>
<?php if($quotation['order']['indoorLooperRp']): ?>
|  <?php echo e(__('office.indoorlooperrp')); ?>   |1.850 <?php echo e(__('office.da')); ?>| x <?php echo e($quotation['order']['indoorLooperRp']); ?> | <?php echo e($quotation['order']['indoorLooperRp'] * 1850); ?> <?php echo e(__('office.da')); ?> |
<?php endif; ?>
<?php if($quotation['order']['indoorLooperPaper']): ?>
|  <?php echo e(__('office.indoorlooperpaper')); ?>   |1.850 <?php echo e(__('office.da')); ?>| x <?php echo e($quotation['order']['indoorLooperPaper']); ?> | <?php echo e($quotation['order']['indoorLooperPaper'] * 1850); ?> <?php echo e(__('office.da')); ?> |
<?php endif; ?>
<?php if($quotation['order']['indoorLooperAluminium']): ?>
|  <?php echo e(__('office.indoorlooperaluminium')); ?>   |1.850 <?php echo e(__('office.da')); ?>| x <?php echo e($quotation['order']['indoorLooperAluminium']); ?> | <?php echo e($quotation['order']['indoorLooperAluminium'] * 1850); ?> <?php echo e(__('office.da')); ?> |
<?php endif; ?>
<?php if($quotation['order']['outdoorLooperPet']): ?>
|  <?php echo e(__('office.outdoorlooperpet')); ?>   |3.650 <?php echo e(__('office.da')); ?>| x <?php echo e($quotation['order']['outdoorLooperPet']); ?> | <?php echo e($quotation['order']['outdoorLooperPet'] * 3650); ?> <?php echo e(__('office.da')); ?> |
<?php endif; ?>
<?php if($quotation['order']['outdoorLooperRp']): ?>
|  <?php echo e(__('office.outdoorlooperrp')); ?>   |3.650 <?php echo e(__('office.da')); ?>| x <?php echo e($quotation['order']['outdoorLooperRp']); ?> | <?php echo e($quotation['order']['outdoorLooperRp'] * 3650); ?> <?php echo e(__('office.da')); ?> |
<?php endif; ?>
<?php if($quotation['order']['outdoorLooperPaper']): ?>
|  <?php echo e(__('office.outdoorlooperpaper')); ?>   |3.650 <?php echo e(__('office.da')); ?>| x <?php echo e($quotation['order']['outdoorLooperPaper']); ?> | <?php echo e($quotation['order']['outdoorLooperPaper'] * 3650); ?> <?php echo e(__('office.da')); ?> |
<?php endif; ?>
<?php if($quotation['order']['outdoorLooperAluminium']): ?>
|  <?php echo e(__('office.outdoorlooperaluminium')); ?>   |3.650 <?php echo e(__('office.da')); ?>| x <?php echo e($quotation['order']['outdoorLooperAluminium']); ?> | <?php echo e($quotation['order']['outdoorLooperAluminium'] * 3650); ?> <?php echo e(__('office.da')); ?> |
<?php endif; ?>
<?php if($quotation['order']['outdoorLooperPetBig']): ?>
|  <?php echo e(__('office.outdoorstationpaper')); ?>   |3.650 <?php echo e(__('office.da')); ?>| x <?php echo e($quotation['order']['outdoorLooperPetBig']); ?> | <?php echo e($quotation['order']['outdoorLooperPetBig'] * 3650); ?> <?php echo e(__('office.da')); ?> |
<?php endif; ?>
<?php if($quotation['order']['outdoorLooperPaperBig']): ?>
|  <?php echo e(__('office.outdoorstationpaper')); ?>   | 3.650 <?php echo e(__('office.da')); ?>| x <?php echo e($quotation['order']['outdoorLooperPaperBig']); ?> | <?php echo e($quotation['order']['outdoorLooperPaperBig'] * 3650); ?> <?php echo e(__('office.da')); ?> |
<?php endif; ?>
<?php if($quotation['order']['bags']): ?>
|  <?php echo e(__('office.nrecyclibags')); ?> 	 | 960 <?php echo e(__('office.da')); ?>| x <?php echo e($quotation['order']['bags']); ?>          | <?php echo e($quotation['order']['bags'] * 960); ?> <?php echo e(__('office.da')); ?> |
<?php endif; ?>
<?php if(true): ?>
|  <?php echo e(__('office.collectcontribution')); ?> |<?php echo e($quotation['collect_contribution_price']); ?> <?php echo e(__('office.da')); ?> | x 1   | <?php echo e($quotation['collect_contribution_price']); ?> <?php echo e(__('office.da')); ?> |
<?php endif; ?>
|  <?php echo e(__('office.nrecycliecotracker')); ?> 		| 0 <?php echo e(__('office.da')); ?>| x <?php echo e($quotation['order']['ecotracker']); ?>    | 0 <?php echo e(__('office.da')); ?>|
<?php if (isset($__componentOriginal20cb600a4a4149597e6997e789a6c2fa917d1906)): ?>
<?php $component = $__componentOriginal20cb600a4a4149597e6997e789a6c2fa917d1906; ?>
<?php unset($__componentOriginal20cb600a4a4149597e6997e789a6c2fa917d1906); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php $__env->startComponent('mail::table'); ?>
|                |                |
| :------------- |-------------:  |
| <?php echo e(__('office.totalht')); ?>    | <?php echo e($quotation['totalht']); ?> <?php echo e(__('office.da')); ?> |
| <?php echo e(__('office.tva')); ?>   | <?php echo e($quotation['tva']); ?> <?php echo e(__('office.da')); ?> |
| <?php echo e(__('office.total')); ?>    | <?php echo e($quotation['total']); ?> <?php echo e(__('office.da')); ?>|

<?php if (isset($__componentOriginal20cb600a4a4149597e6997e789a6c2fa917d1906)): ?>
<?php $component = $__componentOriginal20cb600a4a4149597e6997e789a6c2fa917d1906; ?>
<?php unset($__componentOriginal20cb600a4a4149597e6997e789a6c2fa917d1906); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

<?php $__env->startComponent('mail::subcopy'); ?>
  <div>
    <p style="text-align:left;">
      <!-- <?php echo e(__('office.seventh_msg')); ?><strong style="color:#41E2F8"><?php echo e(__('office.eigth_msg')); ?></strong><br> -->
      <?php echo e(__('office.ninth_msg')); ?><br>
      <?php echo e(__('office.tenth_msg')); ?><strong style="color:#41E2F8"> office.nrecycli.com</strong><br>
      <?php echo e(__('office.eleventh_msg')); ?>

    </p>
  </div>
<?php if (isset($__componentOriginalba845ad32dfe5e4470519a452789aeb20250b6fc)): ?>
<?php $component = $__componentOriginalba845ad32dfe5e4470519a452789aeb20250b6fc; ?>
<?php unset($__componentOriginalba845ad32dfe5e4470519a452789aeb20250b6fc); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>


<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>


<?php /**PATH D:\nrecycli_office\officeApi\example-app\resources\views/emails/quotation.blade.php ENDPATH**/ ?>
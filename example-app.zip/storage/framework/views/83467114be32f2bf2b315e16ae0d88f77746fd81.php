<?php $__env->startComponent('mail::message'); ?>

Suite de l'installation du Nrecycli Office Pack éffectué le <?php echo e($invoice['to_be_delivered_at']); ?> et
 correspendant au devis numéro <?php echo e($invoice['number']); ?> 
 nous vous adressons ci-joint une facture d'un montant de <?php echo e($invoice['total']); ?> DA.
 Il est possible de régler ce montant par chèque auvirement bancaire.
 En vous remerciant par avance,
 cordialement.

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\nrecycli_office\officeApi\example-app\resources\views/emails/invoice.blade.php ENDPATH**/ ?>
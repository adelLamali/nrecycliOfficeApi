<?php  


	return[

		'edit' => 'This change has been made successfully',
		'reset_password_feedback' => 'Your have successfully changed your password',
		'forgot_password_email' => "Thanks! If the Email address you've entered belongs to an account, you will shortly get an email with a link to reset your password.",
		'congrats' => 'Congratulations!',
		'activation_message' => 'Your Account has been approved. Your order will be shipped to you soon. Login and check your calendar to view upcoming pickups.',
		'login' => 'Login',  
		'reset_password' => 'Reset Password',
		'reset_password_message' => 'Did you forget your password?? Try to enter your birthday, your pet’s name maybe or something like that... well if that doesn’t work click below to change the password!',
		'ordertitle' =>'Quotation',
		'item' => 'Item',
		'uniteprice' => 'Unit Price',
		'count' => 'Count',
		'total' => 'Total',
		'tva' => 'Tax 19 %',
		'totalht' => 'Sub Total',
		'send_confirmation' => 'Send Confirmation',
		'da' => 'DZD',
		'placeorder' => 'Check your Email to see the quotation and',
		'yourpasswordisthesame' => 'Your password is not the same',

		'workshop'=>"Workshop: “The Art of Recycling”",
		'nrecyclibags'=>"Nrecycli bags",
		'nrecycliecotracker'=>"Nrecycli Eco-Tracker",
		'collectcontribution'=>"Contribution for the Collection",
		'twostreams'=>"Two Stream Recycling Station",
    	'threestreams'=>"Three Stream Recycling Station",


		'indoorlooperpet'=>"Indoor looper - P.E.T. ",

		'indoorlooperrp'=>"Indoor looper - P.E.H.D et P.P ",

		'indoorlooperpaper'=>"Indoor looper - Papier ",

		'indoorlooperaluminium'=>"Indoor looper - Aluminium ",

		'outdoorlooperpet'=>"Outdoor looper - P.E.T. ",

		'outdoorlooperrp'=>"Outdoor looper - P.E.H.D et P.P ",

		'outdoorlooperpaper'=>"Outdoor looper - Papier ",

		'outdoorlooperaluminium'=>"Outdoor looper - Aluminium ",

		'outdoorstationpet'=>"Outdoor station - P.E.T.",

		'outdoorstationpaper'=>"Outdoor station - Paper",


		'welcome' => "We wlecome you", 
		'first_msg' => "for your initiative to join the Nrecycli eco-responsible office community!",
		'second_msg' => "Together we are the change. ",
		'third_msg' => "Following your quote request,",
		'fourth_msg' => "regarding our ",
		'fifth_msg' => "offer, please find attached our commercial offer.",
		'sixth_msg' => "This proposal takes into account the elements of your order:",
		'seventh_msg' => "Vous avez changé d'avis ?",
		'eigth_msg' => "Personnalisez à nouveau votre commande",
		'ninth_msg' => "This quote is valid until (one week delay from the sending day).",
		'tenth_msg' => "To finalize your order, please return this quote with the words « BON DE COMMANDE » followed by your signature and the date to ",
		'eleventh_msg' => "For any further information or modification of your order, our team remains at your disposal.",

		'facture_msg_one' => "Suite de l'installation du “ Nrecycli Office Pack ” éffectué le",
		'facture_msg_two' => "et correspendant au devis numéro ",
		'facture_msg_three' => "nous vous adressons ci-joint une facture d'un montant de ",
		'facture_msg_four' => "Il est possible de régler ce montant par chèque ou virement bancaire.",
		'facture_msg_five' => "En vous remerciant par avance,",
		'facture_msg_six' => "cordialement."
	
	
	];	